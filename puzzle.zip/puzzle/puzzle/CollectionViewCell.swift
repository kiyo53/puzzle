//
//  CollectionViewCell.swift
//  puzzle
//
//  Created by Ayumi Shimizu on 2018/01/25.
//  Copyright © 2018年 Ayumi Shimizu. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
